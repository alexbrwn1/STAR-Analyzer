"""
Cumulative licks plotting for STAR Analyzer V4.
"""

from typing import List, Tuple, Optional
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.axes import Axes

from core.data_models import Stage

# Stage colors - visually distinct
STAGE_COLORS = {
    Stage.MAG_TRAIN: '#9B59B6',  # Purple
    Stage.FR1_30: '#3498DB',     # Blue
    Stage.FR1_10: '#27AE60',     # Green
    Stage.FR5_10: '#E67E22',     # Orange
    Stage.TESTING: '#E74C3C',    # Red
}

STAGE_LABELS = {
    Stage.MAG_TRAIN: 'Mag Training',
    Stage.FR1_30: 'FR1-30',
    Stage.FR1_10: 'FR1-10',
    Stage.FR5_10: 'FR5-10',
    Stage.TESTING: 'FR10-10',
}


def create_cumulative_licks_plot(
    sessions: List['ParsedSession'],
    mode: str = 'relative',  # 'relative' or 'absolute'
    highlighted_day: Optional[int] = None,  # Day to highlight (None = most recent)
    figsize: Tuple[float, float] = (10, 6),
) -> Tuple[Figure, Axes]:
    """
    Create cumulative licks plot for a single subject across multiple sessions.

    Args:
        sessions: List of ParsedSession objects for ONE subject, sorted by day
        mode: 'relative' (0-100%) or 'absolute' (raw lick counts)
        highlighted_day: Day number to highlight (bold). If None, highlights most recent.
        figsize: Figure dimensions

    Returns:
        (figure, axes) tuple
    """
    fig, ax = plt.subplots(figsize=figsize, facecolor='white')
    ax.set_facecolor('white')

    if not sessions:
        ax.text(0.5, 0.5, 'No sessions to display',
                ha='center', va='center', fontsize=14, color='gray')
        return fig, ax

    # Find most recent session (highest day_in_cohort) for default highlight
    max_day = max(s.day_in_cohort for s in sessions)
    if highlighted_day is None:
        highlighted_day = max_day

    # Track max licks for absolute mode y-axis scaling
    max_licks = 0

    # Plot each session
    for session in sessions:
        lick_times = session.session.timestamps.lick_onset_timestamps

        if not lick_times:
            continue

        # Sort timestamps and create cumulative count
        lick_times_sorted = sorted(lick_times)
        cumulative = list(range(1, len(lick_times_sorted) + 1))

        # Track max for absolute mode
        max_licks = max(max_licks, len(cumulative))

        # Get session duration for normalization
        duration = session.session.scalars.session_time or lick_times_sorted[-1]

        # Build x and y values
        # Start at origin (0, 0)
        x_values = [0.0]
        y_values = [0.0]

        # Add all lick points
        if mode == 'relative':
            total_licks = len(cumulative)
            for t, c in zip(lick_times_sorted, cumulative):
                x_values.append(t / duration * 100)
                y_values.append(c / total_licks * 100)
        else:  # absolute
            for t, c in zip(lick_times_sorted, cumulative):
                x_values.append(t / duration * 100)
                y_values.append(c)

        # Extend line to end of session (100%) with final lick count
        if x_values[-1] < 100:
            x_values.append(100.0)
            y_values.append(y_values[-1])

        # Determine line style based on highlighted day
        is_highlighted = (session.day_in_cohort == highlighted_day)
        linewidth = 3 if is_highlighted else 1.5
        alpha = 1.0 if is_highlighted else 0.7

        # Get color from stage
        color = STAGE_COLORS.get(session.stage, '#888888')

        # Create label for legend
        label = f"Day {session.day_in_cohort}: {STAGE_LABELS.get(session.stage, session.stage_name)}"

        line, = ax.plot(x_values, y_values, color=color, linewidth=linewidth,
                        alpha=alpha, label=label)
        # Store day number on the line for pick event handling
        line._day_in_cohort = session.day_in_cohort

    # Add 100-lick criterion line (only in absolute mode)
    if mode == 'absolute':
        ax.axhline(y=100, color='#00CCCC', linestyle='--',
                   linewidth=2, alpha=0.7, label='100-lick criterion')

    # Axis labels and limits
    ax.set_xlabel('Session Progress (%)', fontsize=11)
    ax.set_xlim(0, 100)

    if mode == 'relative':
        ax.set_ylabel('Licks (% of session total)', fontsize=11)
        ax.set_ylim(0, 105)
    else:
        ax.set_ylabel('Cumulative Licks', fontsize=11)
        ax.set_ylim(0, max(max_licks * 1.1, 110))  # At least show 100-lick line

    # Grid and styling
    ax.grid(True, alpha=0.3, linestyle=':')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    # Title
    if sessions:
        subject = sessions[0].subject_id
        ax.set_title(f'Subject {subject} - Cumulative Licks ({mode.title()} Mode)',
                     fontsize=12, fontweight='bold')

    # Legend (outside plot, right side) - make entries pickable
    legend = ax.legend(loc='upper left', fontsize=9, framealpha=0.9)

    # Make legend lines pickable and copy day info to legend lines
    if legend:
        # Get the original plot lines and legend lines
        plot_lines = [child for child in ax.get_children()
                      if hasattr(child, '_day_in_cohort')]
        legend_lines = legend.get_lines()

        # Map legend lines to their corresponding day numbers
        for leg_line, plot_line in zip(legend_lines, plot_lines):
            leg_line.set_picker(True)
            leg_line.set_pickradius(10)
            leg_line._day_in_cohort = plot_line._day_in_cohort

    plt.tight_layout()
    return fig, ax


def create_day_licks_plot(
    sessions: List['ParsedSession'],
    mode: str = 'relative',
    figsize: Tuple[float, float] = (10, 6),
) -> Tuple[Figure, Axes]:
    """
    Plot cumulative licks for all animals on a single day.
    Lines colored by stage (program) run, labeled by subject_id.
    """
    fig, ax = plt.subplots(figsize=figsize, facecolor='white')
    ax.set_facecolor('white')

    if not sessions:
        ax.text(0.5, 0.5, 'No sessions for this day',
                ha='center', va='center', fontsize=14, color='gray')
        return fig, ax

    day = sessions[0].day_in_cohort if sessions else '?'
    max_licks = 0

    for session in sessions:
        lick_times = session.session.timestamps.lick_onset_timestamps
        if not lick_times:
            continue

        lick_times_sorted = sorted(lick_times)
        cumulative = list(range(1, len(lick_times_sorted) + 1))
        max_licks = max(max_licks, len(cumulative))
        duration = session.session.scalars.session_time or lick_times_sorted[-1]

        x_values = [0.0]
        y_values = [0.0]
        if mode == 'relative':
            total_licks = len(cumulative)
            for t, c in zip(lick_times_sorted, cumulative):
                x_values.append(t / duration * 100)
                y_values.append(c / total_licks * 100)
        else:
            for t, c in zip(lick_times_sorted, cumulative):
                x_values.append(t / duration * 100)
                y_values.append(c)

        if x_values[-1] < 100:
            x_values.append(100.0)
            y_values.append(y_values[-1])

        color = STAGE_COLORS.get(session.stage, '#888888')
        label = f"{session.subject_id} ({STAGE_LABELS.get(session.stage, session.stage_name)})"
        ax.plot(x_values, y_values, color=color, linewidth=1.5, alpha=0.85, label=label)

    if mode == 'absolute':
        ax.axhline(y=100, color='#00CCCC', linestyle='--', linewidth=2, alpha=0.7, label='100-lick criterion')

    ax.set_xlabel('Session Progress (%)', fontsize=11)
    ax.set_xlim(0, 100)
    if mode == 'relative':
        ax.set_ylabel('Licks (% of session total)', fontsize=11)
        ax.set_ylim(0, 105)
    else:
        ax.set_ylabel('Cumulative Licks', fontsize=11)
        ax.set_ylim(0, max(max_licks * 1.1, 110))

    ax.set_title(f'Day {day} — All Animals (Cumulative Licks, {mode.title()} Mode)',
                 fontsize=12, fontweight='bold')
    ax.grid(True, alpha=0.3, linestyle=':')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.legend(loc='upper left', fontsize=9, framealpha=0.9)
    plt.tight_layout()
    return fig, ax


def create_stage_legend_figure(figsize: Tuple[float, float] = (3, 2)) -> Figure:
    """Create a standalone legend showing stage colors."""
    fig, ax = plt.subplots(figsize=figsize, facecolor='white')
    ax.set_axis_off()

    for stage, color in STAGE_COLORS.items():
        label = STAGE_LABELS.get(stage, str(stage))
        ax.plot([0], [0], color=color, linewidth=3, label=label)

    ax.legend(loc='center', fontsize=10, frameon=False)
    return fig
