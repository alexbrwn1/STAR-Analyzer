"""
Excel exporter for STAR Analyzer V4.
Multi-sheet export with All Sessions + per-subject tabs + Progress Tracker.
"""

from pathlib import Path
from typing import List, Optional, Dict
from datetime import datetime

from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter

from core.session_manager import ParsedSession
from core.data_models import Stage, AnimalState, SessionResult


class ExcelExporter:
    """Exports parsed sessions to multi-sheet Excel files."""

    # Column definitions
    COLUMNS = [
        ('Subject', 10),
        ('Cohort Day', 10),        # NEW
        ('Date', 12),
        ('Time', 10),
        ('Experiment', 15),
        ('Stage', 12),
        ('Active', 10),
        ('Inactive', 10),
        ('Reinforcers', 12),       # Swapped - before Licks
        ('Licks', 10),             # Swapped - after Reinforcers
        ('Discrim %', 12),
        ('Duration (min)', 14),
        ('Pass', 8),
        ('MSN', 25),
    ]

    # Stage display names for Session column in Next Day Setup
    STAGE_DISPLAY = {
        Stage.MAG_TRAIN: "Mag Training",
        Stage.FR1_30: "FR1-30",
        Stage.FR1_10: "FR1-10",
        Stage.FR5_10: "FR5-10",
        Stage.TRAINED: "Trained",
        Stage.TESTING: "Test",
    }

    # MedPC program names by stage
    PROGRAM_NAMES = {
        Stage.MAG_TRAIN: "00_STAR_MagTraining_NoCap",
        Stage.FR1_30: "01_{SIDE}_STAR_Acq_FR1_30s_NoCap",
        Stage.FR1_10: "02_{SIDE}_STAR_Acq_FR1_10s_NoCap",
        Stage.FR5_10: "04_{SIDE}_STAR_Acq_FR5_10s_NoCap",
        Stage.TESTING: "05_{SIDE}_STAR_Test_FR10_10s_NoCap",
    }

    # Styles
    HEADER_FILL = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
    HEADER_FONT = Font(bold=True, color='FFFFFF')
    PASS_FILL = PatternFill(start_color='C6EFCE', end_color='C6EFCE', fill_type='solid')
    PARTIAL_FILL = PatternFill(start_color='FFEB9C', end_color='FFEB9C', fill_type='solid')
    FAIL_FILL = PatternFill(start_color='FFC7CE', end_color='FFC7CE', fill_type='solid')
    THIN_BORDER = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )

    def export_sessions(self, sessions: List[ParsedSession], filepath: Path) -> None:
        """
        Export sessions to Excel with multiple sheets.

        Creates:
        - "All Sessions" sheet with all data
        - Per-subject sheets (e.g., "Subject 1", "Subject 2")
        """
        if not sessions:
            raise ValueError("No sessions to export")

        wb = Workbook()

        # Sheet 1: All Sessions — animal order (M1..MN, F1..FN), day ascending within each animal
        ws_all = wb.active
        ws_all.title = "All Sessions"
        self._write_session_sheet(ws_all, sorted(sessions,
            key=lambda s: (*self._session_animal_key(s), s.day_in_cohort)))

        # Sheet 2: Most Recent Day — same animal order (M1..MN, F1..FN)
        max_day = max(s.day_in_cohort for s in sessions)
        if max_day > 0:
            recent_sessions = [s for s in sessions if s.day_in_cohort == max_day]
            ws_recent = wb.create_sheet(title=f"Day {max_day} (Latest)", index=1)
            self._write_session_sheet(ws_recent, sorted(recent_sessions,
                key=lambda s: self._session_animal_key(s)))

        # Sheet 3: Progress Tracker (moved before per-subject sheets)
        ws_tracker = wb.create_sheet(title="Progress Tracker", index=2)
        self._write_tracker_sheet(ws_tracker, sessions)

        # Group sessions by subject
        by_subject = {}
        for session in sessions:
            by_subject.setdefault(session.subject_id, []).append(session)

        # Sheets 4+: Per-subject sheets
        for subject_id in sorted(by_subject.keys(), key=self._sort_subject_key):
            sheet_name = f"Subject {subject_id}"[:31]  # Excel limits sheet names to 31 chars
            ws = wb.create_sheet(title=sheet_name)
            subject_sessions = sorted(by_subject[subject_id], key=lambda s: s.date)
            self._write_session_sheet(ws, subject_sessions)

        # Save workbook
        wb.save(filepath)

    def _sort_subject_key(self, subject_id: str):
        """Sort subjects: males (M1, M2...) then females (F1, F2...)."""
        import re
        sid = subject_id.upper()
        sex = 0 if sid.startswith('M') else (1 if sid.startswith('F') else 2)
        match = re.search(r'(\d+)', subject_id)
        num = int(match.group(1)) if match else 999
        return (sex, num, subject_id)

    def _session_animal_key(self, session: 'ParsedSession'):
        """Return the M→F sort tuple for a session (sex, number, subject_id)."""
        return self._sort_subject_key(session.subject_id)

    def _write_session_sheet(self, ws, sessions: List[ParsedSession]) -> None:
        """Write session data to a worksheet."""
        # Write header row
        for col_idx, (col_name, col_width) in enumerate(self.COLUMNS, start=1):
            cell = ws.cell(row=1, column=col_idx, value=col_name)
            cell.fill = self.HEADER_FILL
            cell.font = self.HEADER_FONT
            cell.alignment = Alignment(horizontal='center')
            cell.border = self.THIN_BORDER
            ws.column_dimensions[get_column_letter(col_idx)].width = col_width

        # Write data rows
        for row_idx, session in enumerate(sessions, start=2):
            row_data = self._session_to_row(session)

            for col_idx, value in enumerate(row_data, start=1):
                cell = ws.cell(row=row_idx, column=col_idx, value=value)
                cell.border = self.THIN_BORDER

                # Center align most columns
                if col_idx not in [5, 14]:  # Experiment and MSN are left-aligned (shifted by 1)
                    cell.alignment = Alignment(horizontal='center')

            # Color the Pass column based on value (column 13 now)
            pass_cell = ws.cell(row=row_idx, column=13)
            if pass_cell.value == 'Pass':
                pass_cell.fill = self.PASS_FILL
            elif pass_cell.value == 'Partial':
                pass_cell.fill = self.PARTIAL_FILL
            elif pass_cell.value == 'Fail':
                pass_cell.fill = self.FAIL_FILL

        # Freeze header row
        ws.freeze_panes = 'A2'

    def _session_to_row(self, session: ParsedSession) -> list:
        """Convert a ParsedSession to a row of values."""
        # Calculate discrimination percentage
        total_lever = session.active_presses + session.inactive_presses
        discrim_pct = (session.active_presses / total_lever * 100) if total_lever > 0 else 0

        # Determine pass status string
        if session.pass_status == 'partial':
            pass_str = 'Partial'
        elif session.passed:
            pass_str = 'Pass'
        else:
            pass_str = 'Fail'

        # Format date (already a string in ParsedSession)
        date_str = session.date or ''

        # Get time from the underlying MedPCSession
        time_str = ''
        if session.session and session.session.metadata.start_time:
            time_str = session.session.metadata.start_time.strftime('%H:%M:%S')

        # Get experiment and MSN from underlying session
        experiment = session.session.metadata.experiment if session.session else ''
        msn = session.session.metadata.msn if session.session else ''

        # Calculate duration in minutes from session_time scalar
        duration_min = 0
        if session.session and session.session.scalars.session_time:
            duration_min = session.session.scalars.session_time / 60

        return [
            session.subject_id,
            session.day_in_cohort,      # NEW - Cohort Day
            date_str,
            time_str,
            experiment,
            session.stage_name,
            session.active_presses,
            session.inactive_presses,
            session.reinforcers,        # SWAPPED - before Licks
            session.licks,              # SWAPPED - after Reinforcers
            round(discrim_pct, 1),
            round(duration_min, 1),
            pass_str,
            msn,
        ]

    def _write_tracker_sheet(self, ws, sessions: List[ParsedSession]) -> None:
        """Write the Progress Tracker sheet with day-by-day grid and next day setup."""
        if not sessions:
            return

        # Build animal states from sessions
        animal_states = self._build_animal_states(sessions)
        if not animal_states:
            return

        # Get all unique days and sort subjects
        all_days = sorted(set(s.day_in_cohort for s in sessions if s.day_in_cohort > 0))
        sorted_subjects = sorted(animal_states.keys(), key=self._sort_subject_key)

        # Group sessions by subject and day for lookup
        sessions_by_subject_day: Dict[str, Dict[int, ParsedSession]] = {}
        for s in sessions:
            if s.subject_id not in sessions_by_subject_day:
                sessions_by_subject_day[s.subject_id] = {}
            sessions_by_subject_day[s.subject_id][s.day_in_cohort] = s

        # ======================
        # Section 1: Day-by-Day Grid
        # ======================
        row = 1

        # Title row
        title_cell = ws.cell(row=row, column=1, value="TRAINING PROGRESS")
        title_cell.font = Font(bold=True, size=14)
        row += 2  # Skip blank row

        # Header row 1: Animal ID + Day headers (merged 3 cols each)
        ws.cell(row=row, column=1, value="Animal ID")
        ws.cell(row=row, column=1).fill = self.HEADER_FILL
        ws.cell(row=row, column=1).font = self.HEADER_FONT
        ws.cell(row=row, column=1).border = self.THIN_BORDER
        ws.cell(row=row, column=1).alignment = Alignment(horizontal='center')

        col = 2
        for day in all_days:
            # Merge 3 columns for each day
            ws.merge_cells(start_row=row, start_column=col, end_row=row, end_column=col+2)
            day_cell = ws.cell(row=row, column=col, value=f"Day {day}")
            day_cell.fill = self.HEADER_FILL
            day_cell.font = self.HEADER_FONT
            day_cell.alignment = Alignment(horizontal='center')
            day_cell.border = self.THIN_BORDER
            # Border for merged cells
            for c in range(col, col+3):
                ws.cell(row=row, column=c).border = self.THIN_BORDER
            col += 3

        row += 1

        # Header row 2: Sub-headers (Program | Day | Pass?)
        ws.cell(row=row, column=1, value="")  # Empty under Animal ID
        ws.cell(row=row, column=1).border = self.THIN_BORDER

        col = 2
        for _ in all_days:
            for sub_header in ["Program", "Day", "Pass?"]:
                cell = ws.cell(row=row, column=col, value=sub_header)
                cell.fill = self.HEADER_FILL
                cell.font = self.HEADER_FONT
                cell.alignment = Alignment(horizontal='center')
                cell.border = self.THIN_BORDER
                col += 1

        row += 1

        # Data rows for each animal
        for subject_id in sorted_subjects:
            ws.cell(row=row, column=1, value=subject_id)
            ws.cell(row=row, column=1).border = self.THIN_BORDER
            ws.cell(row=row, column=1).alignment = Alignment(horizontal='center')

            col = 2
            for day in all_days:
                session = sessions_by_subject_day.get(subject_id, {}).get(day)

                if session:
                    # Program (stage name)
                    stage_name = self.STAGE_DISPLAY.get(session.stage, session.stage_name)
                    ws.cell(row=row, column=col, value=stage_name)
                    ws.cell(row=row, column=col).border = self.THIN_BORDER
                    ws.cell(row=row, column=col).alignment = Alignment(horizontal='center')

                    # Day in stage - calculate from history
                    day_in_stage = self._get_day_in_stage(sessions_by_subject_day.get(subject_id, {}), day, session.stage)
                    ws.cell(row=row, column=col+1, value=day_in_stage)
                    ws.cell(row=row, column=col+1).border = self.THIN_BORDER
                    ws.cell(row=row, column=col+1).alignment = Alignment(horizontal='center')

                    # Pass?
                    if session.pass_status == 'partial':
                        pass_val = "Partial"
                        fill = self.PARTIAL_FILL
                    elif session.passed:
                        pass_val = "Yes"
                        fill = self.PASS_FILL
                    else:
                        pass_val = "No"
                        fill = self.FAIL_FILL

                    pass_cell = ws.cell(row=row, column=col+2, value=pass_val)
                    pass_cell.fill = fill
                    pass_cell.border = self.THIN_BORDER
                    pass_cell.alignment = Alignment(horizontal='center')
                else:
                    # Empty cells for missing day
                    for offset in range(3):
                        ws.cell(row=row, column=col+offset, value="")
                        ws.cell(row=row, column=col+offset).border = self.THIN_BORDER

                col += 3

            row += 1

        # Set column widths for grid section
        ws.column_dimensions['A'].width = 12
        col = 2
        for _ in all_days:
            ws.column_dimensions[get_column_letter(col)].width = 12      # Program
            ws.column_dimensions[get_column_letter(col+1)].width = 6     # Day
            ws.column_dimensions[get_column_letter(col+2)].width = 8     # Pass?
            col += 3

        # ======================
        # Section 2: Next Day Setup
        # ======================
        row += 2  # Skip blank rows
        next_cohort_day = max(all_days) + 1 if all_days else 1

        # Title
        title_cell = ws.cell(row=row, column=1, value=f"NEXT DAY SETUP - Cohort Day {next_cohort_day}")
        title_cell.font = Font(bold=True, size=12)
        row += 1

        # Header row
        headers = ["Animal ID", "Session", "Program"]
        for col_idx, header in enumerate(headers, start=1):
            cell = ws.cell(row=row, column=col_idx, value=header)
            cell.fill = self.HEADER_FILL
            cell.font = self.HEADER_FONT
            cell.alignment = Alignment(horizontal='center')
            cell.border = self.THIN_BORDER

        ws.column_dimensions['B'].width = 20  # Session column
        ws.column_dimensions['C'].width = 35  # Program column

        row += 1

        # Data rows for next day
        for subject_id in sorted_subjects:
            state = animal_states[subject_id]

            # Animal ID
            ws.cell(row=row, column=1, value=subject_id)
            ws.cell(row=row, column=1).border = self.THIN_BORDER
            ws.cell(row=row, column=1).alignment = Alignment(horizontal='center')

            # Calculate next stage and day
            next_stage, next_day_in_stage = self._get_next_session_info(state)
            stage_display = self.STAGE_DISPLAY.get(next_stage, str(next_stage))
            session_str = f"{stage_display} Day {next_day_in_stage}"

            ws.cell(row=row, column=2, value=session_str)
            ws.cell(row=row, column=2).border = self.THIN_BORDER
            ws.cell(row=row, column=2).alignment = Alignment(horizontal='center')

            # Program name with correct side
            active_side = self._get_animal_active_side(sessions, subject_id)
            program = self._get_program_name(next_stage, active_side)

            ws.cell(row=row, column=3, value=program)
            ws.cell(row=row, column=3).border = self.THIN_BORDER
            ws.cell(row=row, column=3).alignment = Alignment(horizontal='left')

            row += 1

    def _build_animal_states(self, sessions: List[ParsedSession]) -> Dict[str, AnimalState]:
        """Build AnimalState objects from sessions."""
        # Group sessions by subject
        sessions_by_subject: Dict[str, List[ParsedSession]] = {}
        for s in sessions:
            if s.subject_id not in sessions_by_subject:
                sessions_by_subject[s.subject_id] = []
            sessions_by_subject[s.subject_id].append(s)

        animal_states: Dict[str, AnimalState] = {}

        for subject_id, subj_sessions in sessions_by_subject.items():
            # Sort by day in cohort
            subj_sessions.sort(key=lambda x: x.day_in_cohort)

            state = AnimalState(subject_id=subject_id)

            for session in subj_sessions:
                if session.stage is None:
                    continue

                # Calculate day in stage
                day_in_stage = 1
                for prev in state.history:
                    if prev.stage == session.stage:
                        day_in_stage += 1

                result = SessionResult(
                    date=session.date,
                    subject_id=subject_id,
                    stage=session.stage,
                    licks=session.licks,
                    active_presses=session.active_presses,
                    inactive_presses=session.inactive_presses,
                    passed=session.passed,
                    filename="",
                    pass_status=session.pass_status,
                    day_in_stage=day_in_stage,
                )
                state.process_session(result)

            animal_states[subject_id] = state

        return animal_states

    def _get_day_in_stage(self, subject_sessions: Dict[int, ParsedSession], current_day: int, current_stage: Stage) -> int:
        """Calculate day in stage for a given cohort day."""
        day_count = 0
        for d in sorted(subject_sessions.keys()):
            if d > current_day:
                break
            s = subject_sessions[d]
            if s.stage == current_stage:
                day_count += 1
        return day_count if day_count > 0 else 1

    def _get_next_session_info(self, state: AnimalState) -> tuple:
        """Get the next stage and day in stage for an animal."""
        next_stage = state.current_stage
        # Count current sessions at this stage
        current_stage_count = sum(1 for h in state.history if h.stage == next_stage)
        next_day_in_stage = current_stage_count + 1

        return next_stage, next_day_in_stage

    def _get_animal_active_side(self, sessions: List[ParsedSession], subject_id: str) -> str:
        """Even-numbered animals (M2, F4...) = RIGHT; odd-numbered (M1, F3...) = LEFT."""
        import re
        match = re.search(r'(\d+)', subject_id)
        if match:
            num = int(match.group(1))
            return "RIGHT" if num % 2 == 0 else "LEFT"
        # Fallback: read from session data
        for s in sessions:
            if s.subject_id == subject_id and s.session and s.session.protocol.active_lever:
                return s.session.protocol.active_lever
        return "LEFT"

    def _get_program_name(self, stage: Stage, active_side: str) -> str:
        """Get the MedPC program name for a stage with correct side."""
        program = self.PROGRAM_NAMES.get(stage, "")
        return program.replace("{SIDE}", active_side.upper())


class TrackerExporter:
    """Exports tracker progress data to Excel."""

    def export_tracker(self, tracker, filepath: Path) -> None:
        """
        Export tracker state to Excel.

        Creates a summary sheet with animal progress.
        """
        from core.data_models import AnimalState

        wb = Workbook()
        ws = wb.active
        ws.title = "Progress Summary"

        # Header
        headers = ['Subject', 'Current Stage', 'Session Day', 'Consecutive Passes',
                   'Consecutive Fails', 'Total Sessions', 'Status']
        for col_idx, header in enumerate(headers, start=1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.fill = ExcelExporter.HEADER_FILL
            cell.font = ExcelExporter.HEADER_FONT
            cell.alignment = Alignment(horizontal='center')
            cell.border = ExcelExporter.THIN_BORDER

        # Data rows
        row_idx = 2
        for animal_id, animal_state in sorted(tracker.animals.items(),
                                               key=lambda x: ExcelExporter()._sort_subject_key(x[0])):
            ws.cell(row=row_idx, column=1, value=animal_id)
            ws.cell(row=row_idx, column=2, value=animal_state.current_stage.name)
            ws.cell(row=row_idx, column=3, value=animal_state.session_day)
            ws.cell(row=row_idx, column=4, value=animal_state.consecutive_passes)
            ws.cell(row=row_idx, column=5, value=animal_state.consecutive_fails)
            ws.cell(row=row_idx, column=6, value=len(animal_state.history))

            # Status
            if animal_state.consecutive_fails >= 3:
                status = 'At Risk'
            elif animal_state.consecutive_passes >= 2:
                status = 'Ready to Advance'
            else:
                status = 'In Progress'
            ws.cell(row=row_idx, column=7, value=status)

            for col_idx in range(1, 8):
                ws.cell(row=row_idx, column=col_idx).border = ExcelExporter.THIN_BORDER
                ws.cell(row=row_idx, column=col_idx).alignment = Alignment(horizontal='center')

            row_idx += 1

        # Set column widths
        widths = [10, 15, 12, 18, 16, 15, 15]
        for col_idx, width in enumerate(widths, start=1):
            ws.column_dimensions[get_column_letter(col_idx)].width = width

        ws.freeze_panes = 'A2'
        wb.save(filepath)
