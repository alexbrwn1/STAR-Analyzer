"""
Cumulative Licks visualization view for STAR Analyzer V4.
"""

import tkinter as tk
from tkinter import ttk
from typing import Optional

import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

from core.licks_plotting import create_cumulative_licks_plot, create_day_licks_plot, STAGE_COLORS, STAGE_LABELS
from core.session_manager import SessionManager


class CumulativeLicksView(ttk.Frame):
    """View for cumulative licks visualization."""

    def __init__(self, master, session_manager: Optional[SessionManager] = None, **kwargs):
        super().__init__(master, **kwargs)

        self.session_manager = session_manager
        self._current_figure = None
        self._current_canvas = None
        self._highlighted_day: Optional[int] = None  # None = most recent

        self._create_widgets()

        # Register for data changes
        if self.session_manager:
            self.session_manager.add_data_changed_callback(self._on_data_changed)

    def _create_widgets(self):
        """Create the view layout."""
        # Top control bar
        control_frame = ttk.Frame(self, padding=5)
        control_frame.pack(fill=tk.X)

        # Subject selector
        ttk.Label(control_frame, text='Subject:').pack(side=tk.LEFT, padx=(0, 5))
        self.subject_var = tk.StringVar()
        self.subject_combo = ttk.Combobox(control_frame, textvariable=self.subject_var,
                                           state='readonly', width=15)
        self.subject_combo.pack(side=tk.LEFT, padx=(0, 10))
        self.subject_combo.bind('<<ComboboxSelected>>', self._on_subject_changed)

        # Day selector (shown only when "All Animals" is selected)
        self.day_label = ttk.Label(control_frame, text='Day:')
        self.day_label.pack(side=tk.LEFT, padx=(0, 5))
        self.day_var = tk.StringVar()
        self.day_combo = ttk.Combobox(control_frame, textvariable=self.day_var,
                                      state='readonly', width=8)
        self.day_combo.pack(side=tk.LEFT, padx=(0, 20))
        self.day_combo.bind('<<ComboboxSelected>>', self._on_day_changed)
        # Hide day selector initially
        self.day_label.pack_forget()
        self.day_combo.pack_forget()

        # Mode toggle (Relative / Absolute)
        ttk.Label(control_frame, text='Mode:').pack(side=tk.LEFT, padx=(0, 5))
        self.mode_var = tk.StringVar(value='relative')

        self.relative_radio = ttk.Radiobutton(control_frame, text='Relative (0-100%)',
                                               variable=self.mode_var, value='relative',
                                               command=self._on_mode_changed)
        self.relative_radio.pack(side=tk.LEFT, padx=(0, 10))

        self.absolute_radio = ttk.Radiobutton(control_frame, text='Absolute (Lick Count)',
                                               variable=self.mode_var, value='absolute',
                                               command=self._on_mode_changed)
        self.absolute_radio.pack(side=tk.LEFT)

        # Hint text
        self.hint_label = ttk.Label(control_frame, text='(Click legend to highlight session)',
                                     font=('TkDefaultFont', 8), foreground='gray')
        self.hint_label.pack(side=tk.LEFT, padx=(20, 0))

        # Stage color legend (right side of control bar)
        legend_frame = ttk.Frame(control_frame)
        legend_frame.pack(side=tk.RIGHT, padx=10)

        for stage, color in STAGE_COLORS.items():
            label = STAGE_LABELS.get(stage, str(stage))
            # Color swatch + text
            swatch = tk.Canvas(legend_frame, width=12, height=12,
                              bg=color, highlightthickness=1, highlightbackground='gray')
            swatch.pack(side=tk.LEFT, padx=2)
            ttk.Label(legend_frame, text=label, font=('TkDefaultFont', 8)).pack(side=tk.LEFT, padx=(0, 8))

        # Separator
        ttk.Separator(self, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=5)

        # Plot area (scrollable)
        plot_frame = ttk.Frame(self)
        plot_frame.pack(fill=tk.BOTH, expand=True)

        self.plot_canvas = tk.Canvas(plot_frame, bg='#f0f0f0', highlightthickness=0)
        self.plot_scrollbar = ttk.Scrollbar(plot_frame, orient=tk.VERTICAL,
                                             command=self.plot_canvas.yview)
        self.plot_canvas.configure(yscrollcommand=self.plot_scrollbar.set)

        self.plot_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.plot_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Interior frame for matplotlib figure
        self.plot_interior = ttk.Frame(self.plot_canvas)
        self.plot_canvas_window = self.plot_canvas.create_window((0, 0),
                                                                   window=self.plot_interior,
                                                                   anchor='nw')

        # Bindings
        self.plot_canvas.bind('<MouseWheel>', self._on_mousewheel)
        self.plot_interior.bind('<Configure>', self._on_interior_configure)
        self.plot_canvas.bind('<Configure>', self._on_canvas_configure)

        # Initial empty state
        self._create_empty_plot()

    def _on_mousewheel(self, event):
        """Handle mouse wheel scrolling."""
        self.plot_canvas.yview_scroll(-1 * (event.delta // 120), 'units')

    def _on_interior_configure(self, event=None):
        """Update scroll region when interior changes."""
        self.plot_canvas.configure(scrollregion=self.plot_canvas.bbox('all'))

    def _on_canvas_configure(self, event=None):
        """Update interior width when canvas resizes."""
        canvas_width = event.width if event else self.plot_canvas.winfo_width()
        self.plot_canvas.itemconfig(self.plot_canvas_window, width=canvas_width)

    def _create_empty_plot(self):
        """Show placeholder when no data."""
        fig, ax = plt.subplots(figsize=(10, 6), facecolor='white')
        ax.text(0.5, 0.5, 'Import data and select a subject to view cumulative licks',
                ha='center', va='center', fontsize=14, color='gray')
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)
        self._display_figure(fig)

    def _display_figure(self, fig):
        """Display matplotlib figure in the canvas."""
        # Clear existing
        for widget in self.plot_interior.winfo_children():
            widget.destroy()

        # Create canvas
        canvas = FigureCanvasTkAgg(fig, master=self.plot_interior)

        # Connect pick event for legend interaction
        canvas.mpl_connect('pick_event', self._on_legend_pick)

        canvas.draw()

        canvas_widget = canvas.get_tk_widget()
        canvas_widget.pack(fill=tk.BOTH, expand=True)
        canvas_widget.bind('<MouseWheel>', self._on_mousewheel)

        # Update size
        fig_height = int(fig.get_figheight() * fig.dpi)
        fig_width = int(fig.get_figwidth() * fig.dpi)
        self.plot_interior.configure(height=fig_height, width=fig_width)

        self.plot_canvas.yview_moveto(0)
        self._current_figure = fig
        self._current_canvas = canvas

    def _on_data_changed(self):
        """Handle data change from SessionManager."""
        self._update_subject_list()
        self._highlighted_day = None  # Reset to most recent
        self._update_plot()

    def _update_subject_list(self):
        """Update subject dropdown."""
        if not self.session_manager:
            return

        subjects = self.session_manager.get_all_subjects()
        all_options = subjects + ['All Animals']
        self.subject_combo['values'] = all_options

        # Update day selector options
        days = self.session_manager.get_all_days()
        self.day_combo['values'] = [f'Day {d}' for d in days]

        # Keep current selection if valid, otherwise select first
        current = self.subject_var.get()
        if current not in all_options and all_options:
            self.subject_var.set(all_options[0])

        # Show/hide day selector
        self._update_day_selector_visibility()

    def _update_day_selector_visibility(self):
        """Show day picker only when 'All Animals' is selected."""
        if self.subject_var.get() == 'All Animals':
            self.day_label.pack(side=tk.LEFT, padx=(0, 5))
            self.day_combo.pack(side=tk.LEFT, padx=(0, 20))
            # Default to most recent day if none selected
            if not self.day_var.get() and self.day_combo['values']:
                self.day_var.set(self.day_combo['values'][-1])
        else:
            self.day_label.pack_forget()
            self.day_combo.pack_forget()

    def _on_day_changed(self, event=None):
        """Handle day selection change (All Animals mode)."""
        self._update_plot()

    def _on_subject_changed(self, event=None):
        """Handle subject selection change."""
        self._highlighted_day = None  # Reset to most recent when subject changes
        self._update_day_selector_visibility()
        self._update_plot()

    def _on_mode_changed(self):
        """Handle mode toggle change."""
        self._update_plot()

    def _on_legend_pick(self, event):
        """Handle click on legend entry to highlight that session."""
        # Check if we clicked on a legend line
        if not hasattr(event, 'artist'):
            return

        artist = event.artist
        # Get the day number stored on the artist
        if hasattr(artist, '_day_in_cohort'):
            clicked_day = artist._day_in_cohort
            # Toggle: if already highlighted, keep it (or could reset to None)
            self._highlighted_day = clicked_day
            self._update_plot()

    def _update_plot(self):
        """Redraw the plot with current settings."""
        if not self.session_manager or not self.session_manager.has_data():
            self._create_empty_plot()
            return

        subject = self.subject_var.get()
        if not subject:
            self._create_empty_plot()
            return

        mode = self.mode_var.get()

        if subject == 'All Animals':
            # Get sessions for selected day
            day_str = self.day_var.get()
            if not day_str:
                self._create_empty_plot()
                return
            try:
                day_num = int(day_str.replace('Day ', ''))
            except ValueError:
                self._create_empty_plot()
                return
            all_sessions = self.session_manager.get_all_sessions()
            day_sessions = [s for s in all_sessions if s.day_in_cohort == day_num]
            fig, ax = create_day_licks_plot(day_sessions, mode=mode)
            self._display_figure(fig)
            return

        # Get sessions for this subject
        sessions = self.session_manager.get_sessions_for_subject(subject)
        sessions = sorted(sessions, key=lambda s: s.day_in_cohort)

        if not sessions:
            self._create_empty_plot()
            return

        # Create plot with highlighted day
        fig, ax = create_cumulative_licks_plot(sessions, mode=mode, highlighted_day=self._highlighted_day)
        self._display_figure(fig)

    def refresh(self):
        """Public refresh method."""
        self._update_subject_list()
        self._update_plot()
