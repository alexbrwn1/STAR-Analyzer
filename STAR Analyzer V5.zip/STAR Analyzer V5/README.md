# STAR Analyzer V5

A desktop application for parsing and analyzing Med-PC IV data files from STAR (Structured Tracking of Alcohol Reinforcement) rodent operant self-administration experiments.

## What It Does

STAR Analyzer helps behavioral neuroscience researchers:

1. **Import Med-PC data** — Automatically discovers and parses Med-PC IV output files from a folder
2. **Visualize sessions** — Generate raster plots showing lever presses, licks, and reinforcer deliveries over time
3. **Track training progress** — Monitor each animal's progression through STAR training stages with pass/fail criteria
4. **Analyze licking behavior** — View cumulative lick curves per subject or across all animals for a given day
5. **Export to Excel** — Create formatted multi-sheet spreadsheets organized by animal

---

## Installation

### Prerequisites

Python 3.10 or newer. Check your version:
```
python --version
```

### Step 1: Install Required Packages

Open a terminal, navigate to the `STAR Analyzer V5` folder, and run:
```
pip install matplotlib openpyxl
```

### Step 2: Launch the Application

```
cd "STAR Analyzer V5"
python src/main.py
```

---

## How to Use

### Importing Data

1. Click **Import Data** (or `Ctrl+I`)
2. Browse to a folder containing Med-PC data files
3. The app scans recursively through subfolders
4. Data appears in all three tabs once import completes

**Recommended folder structure:**
```
My Cohort/
├── Day 1/
│   ├── M1_data
│   ├── M2_data
│   └── F1_data
├── Day 2/
│   └── ...
```

Files are identified by their internal Med-PC structure, not by filename or extension.

---

## Tabs

### Raster Plots

- Select sessions from the left panel (Ctrl+click for multiple)
- Use **Subject** and **Day** dropdowns to filter the list
- Sessions always listed in consistent animal order: males (M1, M2...) then females (F1, F2...)
- Scroll the plot area with your mouse wheel
- **Save Plots** saves the currently displayed raster figure

### Progress Tracker

- **Next Day Setup** — shows what stage and program each animal should run next, including active lever side (even-numbered animals = RIGHT, odd = LEFT)
- **Training Progress grid** — day-by-day pass/fail overview (Green = Pass, Yellow = Partial, Red = Fail)
- **Individual Training History** — dropdown to view detailed session metrics for one animal

### Cumulative Licks

- Select an individual animal to see all their sessions overlaid, colored by training stage
- Select **All Animals** to see every animal's lick curve for a specific cohort day (choose the day from the picker that appears)
- Toggle **Relative** (0–100% of session total) or **Absolute** (raw lick count) modes
- Click legend entries to highlight a specific session (individual animal view)
- **Save Plots** saves the currently displayed licks figure

---

## Exporting Data

Click **Export Stats** (`Ctrl+E`) to save an Excel workbook containing:

| Sheet | Contents |
|-------|----------|
| All Sessions | Every session, animals in M→F order, days ascending per animal |
| Day N (Latest) | Most recent cohort day only, M→F order |
| Progress Tracker | Day-by-day grid + next day setup with program names |
| Subject M1, M2... F1... | Per-animal sheets with full session history |

---

## STAR Training Stages

| Stage | Description | Pass Criteria |
|-------|-------------|---------------|
| Mag Train | Magazine training | ≥100 licks (1 pass) |
| FR1-30 | Fixed ratio 1, 30-min session | ≥100 licks (2 consecutive) |
| FR1-10 | Fixed ratio 1, 10-min session | ≥100 licks (2 consecutive) |
| FR5-10 | Fixed ratio 5, 10-min session | ≥100 licks AND ≥70% discrimination (2 consecutive) |
| FR10-10 | Testing phase | 7 days total |

**Regression rule:** 3 consecutive failures returns the animal to the previous stage.

---

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl+I` | Open Import Dialog |
| `Ctrl+E` | Export to Excel |
| `Alt+F4` | Exit |

---

## Troubleshooting

**"No Med-PC data files found"** — Confirm files contain standard Med-PC headers (`Start Date:`, `Subject:`, etc.). Select the parent folder if data is in subfolders.

**Import errors** — The app skips unparseable files and reports a count. Check the terminal for details.

**Plots not displaying** — Ensure sessions are selected in the list. Use View → Refresh Plots if needed.

**Application won't start** — Verify packages: `pip list | grep matplotlib`

---

## Data Privacy

This application runs entirely on your local computer. No data is sent to the internet.
