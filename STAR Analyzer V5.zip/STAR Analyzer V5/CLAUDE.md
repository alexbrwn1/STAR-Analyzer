# STAR Analyzer V5 - Developer Reference

This document is intended for AI assistants and developers making future code changes.

## Project Overview

STAR Analyzer V5 is a desktop application for analyzing Med-PC IV data files from STAR (Structured Tracking of Alcohol Reinforcement) rodent operant experiments.

**Version lineage:**
- V1: Complete functionality (raster plots, progress tracking) but messy code with CustomTkinter dependency
- V2: Clean architecture with standard ttk widgets, limited features
- V3: V2's clean architecture + V1's full feature set, all standard tkinter/ttk
- V4: Added Cumulative Licks visualization tab
- V5: Bug fixes and usability improvements (sort ordering, export layout, active side logic, All Animals licks view, context-aware save)

## Architecture

```
STAR Analyzer V5/
├── src/
│   ├── main.py                 # Entry point - calls gui.app.run()
│   ├── core/                   # GUI-independent business logic
│   │   ├── data_models.py      # Dataclasses: Stage, PassStatus, SessionResult, AnimalState, MedPCSession
│   │   ├── parser.py           # MedPC file parsing, protocol detection
│   │   ├── file_discovery.py   # Recursive file scanning with pattern matching
│   │   ├── tracker.py          # CohortTracker, check_pass_criteria(), progression logic
│   │   ├── plotting.py         # Matplotlib raster plots with pass/fail badges
│   │   ├── licks_plotting.py   # Cumulative licks plot generation (per-subject and all-animals-by-day)
│   │   ├── exporters.py        # Excel export with multi-sheet support
│   │   └── session_manager.py  # Central data layer with observer callbacks
│   └── gui/                    # tkinter/ttk GUI layer
│       ├── app.py              # Main window, three-tab interface
│       ├── config.py           # ConfigManager for persisting user settings
│       ├── import_dialog.py    # Thread-safe import with progress bar
│       ├── licks_view.py       # CumulativeLicksView - licks tab UI
│       └── tracker_view.py     # DayByDayTable, NextDaySetupPanel, SubjectHistoryPanel
```

## Animal Sort Order (Critical)

**All views and exports use the same M→F sort key: males ascending (M1, M2...) then females ascending (F1, F2...).**

This ordering is enforced in four places — keep them in sync if modifying:

| Location | Purpose |
|---|---|
| `session_manager.py` `load_folder()` sort key | Raster plot listbox order |
| `session_manager.py` `get_all_subjects()` | Subject filter dropdowns, licks view subject list |
| `tracker.py` `get_all_animals()` | Progress Tracker display order |
| `exporters.py` `_sort_subject_key()` | All export sheet ordering |

Sort key pattern used everywhere:
```python
sid = subject_id.upper()
sex = 0 if sid.startswith('M') else (1 if sid.startswith('F') else 2)
match = re.search(r'(\d+)', subject_id)
num = int(match.group(1)) if match else 999
return (sex, num, subject_id)
```

## Data Flow

```
User imports folder
    │
    ▼
ImportDialog discovers files (file_discovery.py)
    │
    ▼
Parser creates MedPCSession objects (parser.py)
    │
    ▼
SessionManager.load_folder()
    ├─► Stores ParsedSession objects sorted M→F (for plotting)
    └─► Builds CohortTracker state (for tracking)
    │
    ▼
SessionManager._notify_data_changed()
    ├─► app.py._on_data_changed() → updates raster plots
    ├─► TrackerView._on_data_changed() → updates DayByDayTable
    └─► CumulativeLicksView._on_data_changed() → updates licks plot
```

## Important Classes

### ParsedSession (session_manager.py)
Wrapper around MedPCSession with quick-access attributes for GUI display:
- `subject_id`, `date`, `stage`, `stage_name`
- `licks`, `active_presses`, `inactive_presses`, `reinforcers`
- `passed`, `pass_status`
- `day_in_cohort` - extracted from folder name (e.g., "Day 5" → 5)
- `raw_data` property for plotting compatibility

### SessionManager (session_manager.py)
Central data layer with observer pattern:
- `load_folder(path)` - parses files, builds tracker state, notifies callbacks
- `get_all_sessions()` - returns List[ParsedSession] in M→F order
- `get_all_subjects()` - returns subject IDs in M→F order
- `get_sessions_for_subject(subject_id)` - returns sessions for one subject
- `get_tracker()` - returns CohortTracker
- `add_data_changed_callback(fn)` - register for data change notifications

### CohortTracker (tracker.py)
Tracks animal progression through training stages:
- `animals: Dict[str, AnimalState]` - keyed by subject ID
- `get_all_animals()` - returns list sorted in M→F order

### AnimalState (data_models.py)
Per-animal state machine:
- `current_stage: Stage`
- `consecutive_passes`, `consecutive_fails`
- `history: List[SessionResult]`
- `process_session(result)` - updates state based on pass/fail

### CumulativeLicksView (licks_view.py)
View for cumulative licks visualization:
- Subject dropdown includes individual animals plus "All Animals" option
- When "All Animals" selected, a day picker appears to choose which cohort day to display
- Individual subject view: all sessions overlaid, click legend to highlight one session
- Relative mode (% of session total) or Absolute mode (raw lick count)

## Pass Criteria (tracker.py)

| Stage | Lick Requirement | Discrimination | Passes to Advance |
|-------|------------------|----------------|-------------------|
| MAG_TRAIN | ≥100 | - | 1 |
| FR1_30 | ≥100 | - | 2 consecutive |
| FR1_10 | ≥100 | - | 2 consecutive |
| FR5_10 | ≥100 | ≥70% | 2 consecutive |
| TESTING | Always passes | - | 7 days total |

- 3 consecutive failures → regression to previous stage
- "Partial" pass = met one FR5-10 criterion but not both (yellow badge)

## GUI Components

### Tab 1: Raster Plots (app.py)
- Left panel: Subject/Day filter dropdowns, session listbox with multi-select
- Right panel: Scrollable canvas containing matplotlib figure
- Sessions listed in M→F order, day ascending within each animal

### Tab 2: Progress Tracker (tracker_view.py)
- **NextDaySetupPanel**: Table showing next session for each animal (M→F order)
- **DayByDayTable**: Canvas-drawn grid with color-coded pass/fail cells
- **SubjectHistoryPanel**: Dropdown + detailed history table for one animal

### Tab 3: Cumulative Licks (licks_view.py)
- **Control bar**: Subject dropdown (animals + "All Animals"), Mode radio buttons, stage color legend
- **Day picker**: Appears only when "All Animals" selected
- **Plot area**: Scrollable matplotlib figure
- **Save Plots**: Context-aware — saves licks figure when on this tab, raster figure from Tab 1

## Cumulative Licks Plot Details (licks_plotting.py)

### Stage Colors
```python
STAGE_COLORS = {
    Stage.MAG_TRAIN: '#9B59B6',  # Purple
    Stage.FR1_30: '#3498DB',     # Blue
    Stage.FR1_10: '#27AE60',     # Green
    Stage.FR5_10: '#E67E22',     # Orange
    Stage.TESTING: '#E74C3C',    # Red
}
```

Two plot functions:
- `create_cumulative_licks_plot()` — one subject, all days overlaid, pickable legend
- `create_day_licks_plot()` — one day, all animals overlaid, labeled by subject_id

## Excel Export (exporters.py)

Sheet order in exported workbook:
1. **All Sessions** — all data, M→F animal order, day ascending within each animal
2. **Day N (Latest)** — most recent day only, M→F order
3. **Progress Tracker** — day-by-day grid + next day setup panel
4. **Subject M1**, **Subject M2**... **Subject F1**... — per-animal sheets

Columns: Subject, Cohort Day, Date, Time, Experiment, Stage, Active, Inactive, Reinforcers, Licks, Discrim%, Duration (min), Pass, MSN

Active lever side in Next Day Setup: determined by even/odd animal number (even = RIGHT, odd = LEFT), falling back to session data if no number found.

## Thread Safety

Import operations run in background thread (import_dialog.py):
- `_run_import()` runs in daemon thread
- Uses `queue.Queue` for thread-safe UI updates
- Main thread polls queue with `after(50, _process_queue)`

## Dependencies

- **matplotlib**: Raster plot and cumulative licks plot generation (TkAgg backend)
- **openpyxl**: Excel file creation with formatting
- Standard library: tkinter, threading, queue, dataclasses, pathlib, re, json

## Common Modifications

### Adding a new training stage
1. Add to `Stage` enum in `data_models.py`
2. Add detection pattern in `parser.py` `detect_training_stage()`
3. Add pass criteria in `tracker.py` `check_pass_criteria()`
4. Add display name in `session_manager.py` `_parse_session()`
5. Add short name in `tracker_view.py` `_short_stage_name()`
6. Add color in `licks_plotting.py` `STAGE_COLORS`
7. Add label in `licks_plotting.py` `STAGE_LABELS`

### Adding a new export column
1. Add to `COLUMNS` list in `exporters.py`
2. Add value to return list in `_session_to_row()`

### Adding a new tab
1. Create plotting module in `core/`
2. Create view class in `gui/` extending `ttk.Frame`
3. Register for `session_manager.add_data_changed_callback()`
4. In `app.py`: add import, create frame + notebook entry, add `_update_*_view()` called from `_on_data_changed()`

## Test Data

Mock data location: `STAR Analyzer V1/Mock Cohort 1 Data by Day/` (in the parent STAR_Analyzer folder)
- 11 days of data for multiple subjects
- Covers all training stages from MAG_TRAIN through FR10-10 testing
- Run `python src/main.py` from the V5 folder to launch
